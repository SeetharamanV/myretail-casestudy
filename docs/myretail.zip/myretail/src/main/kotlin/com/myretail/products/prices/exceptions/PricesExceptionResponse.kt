package com.myretail.products.prices.exceptions

class PricesExceptionResponse(
    val message: String,
    val code: String
)
