package com.myretail.products.details.exceptions

class DetailsExceptionResponse(
    val message: String,
    val code: String
)
