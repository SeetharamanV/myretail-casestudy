package com.myretail.products.prices.domains

enum class PriceType {
    CURRENT_PRICE,
    INITIAL_PRICE,
    RETAIL_PRICE
}
