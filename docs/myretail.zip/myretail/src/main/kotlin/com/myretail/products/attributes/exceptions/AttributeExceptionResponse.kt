package com.myretail.products.attributes.exceptions

class AttributeExceptionResponse(
    val message: String,
    val code: String
)
